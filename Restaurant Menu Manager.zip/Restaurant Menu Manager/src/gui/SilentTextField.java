package gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

public class SilentTextField extends JTextField {

	private boolean listenersEnabled;

	public SilentTextField(int length) {
		
		super(length);
	}
	
	@Override
	public synchronized void addActionListener(ActionListener l) {

		super.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {

				if (listenersEnabled) {

					l.actionPerformed(e);
				}
			}
		});
	}
	
	public void setTextSilent(String text) {

		listenersEnabled = false;
		setText(text);
		listenersEnabled = true;
	}


}
