package restaurantMenuManager;

import java.util.ArrayList;

/*
 * Order is the data class for orders
 *
 * Author: Nick Chen
 * Date: June 18, 2022
 */

public class Order extends ArrayList<MenuItem> {}
